<?php
/**
 * Created by PhpStorm.
 * User: JM
 * Date: 4/4/2016
 * Time: 10:37 p.m.
 */

return [
    'title.page' => 'Contacto',
    'column1.title' => 'Contacto',
    'slogan' => 'Estamos aquí para responder cualquier pregunta que pueda tener',
    'form.title' => 'Sus datos',
    'label.name' => 'Nombre',
    'label.email' => 'Correo',
    'label.subject' => 'Asunto',
    'label.message' => 'Su mensaje',
    'button.send' => 'Enviar',

    'colum2.title' => 'Dónde estamos',
    'error' => 'Hay problemas para enviarnos su mensaje',
];