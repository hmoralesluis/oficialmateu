<?php
/**
 * Created by PhpStorm.
 * User: JM
 * Date: 4/4/2016
 * Time: 10:00 p.m.
 */

return [
    'title.page' => 'About us',
    'title.section1' => 'WE ARE MATEU EXPORT S.L',
    'title.section2' => 'SCOPE',
    'title.section3' => 'GRATIFICATION',
    'title.section4' => 'SUPPLIER',

    'content1.section1' => 'A group of spanish family (Relatives) bussines,
                            with a large tradition throught several generations,
                            with more thaín 60 years of experience in the international
                            market and inserted in the industrial supply chain,
                            designed to mitigate the pressures of modern manufacturig.',

    'content2.section1' => 'Mateu export,
                            located in the middle of catalunya,
                            one of the most advanced regions of Europe and fourth driving force in EU.',

    'content.section2' => 'Our company is present in 70 countries of the 5 continets,
                          throught our 73 representatives and distributors in each one.
                          We work as close as possible of our customers for know their problems and needs as soon as possible.',

    'content.section3' => 'Our companies, modest, with little bureaucracy and without luxuries,
                            they do not have to affect these costs on items to sell.
                            It is in our interest to have regular customers and to grow our family of customers.
                            Here each costumer is not a number,
                            is someone very dear, to which we are pleased to have always satisfied in quality, price and service.',

    'content.section4' => 'We are not affiliated to any manufacturer for a good reason.
                           So that we are able to offer our customers the opinion faster,
                            more flexible and more economic.'





];