<?php
/**
 * Created by PhpStorm.
 * User: JM
 * Date: 4/4/2016
 * Time: 10:19 p.m.
 */

return [

    'title.page' => 'Services',

    'content1.section1' =>'With more than 60 years of experience in the industrial supply, specialy in the spare parts world',
    'content2.section1' => 'With our parts line and modules of spare parts for control system, automation or PLC',
    'title1.section1' => 'We want to offer: ',

    'box1.section1' => 'Spare parts for automation',
    'box2.section1' => 'We understand the pressure of the modern industry',
    'box3.section1' => 'Personalized service to each one of our customers',


    'title.section2' => 'SPARE PARTS FOR AUTOMATION',
    'title.section3' => 'UNDERSTAND THE PRESSURE OF THE MODERN MANUFACTORING',
    'title.section4' => 'PERONALIZED SERVICES TO EACH ONE OF OUR COSTUMERS',


    'content1.section2' => 'Competitive products in all our areas both in quality, price and service.  Lastest-generation products and stock of discontinued products by big companies, that we can provide you so that you do not have to change their equipment, if you do not want. ',
    'content2.section2' => 'Thousands of products of more than 100 manufacturers, which are detailed and organized in our database. Our stock is continually growing as we incorporate new lines and manufacturers to out catalog. ',
    'content3.section2' => 'We have a wide network of collaboration of foreign partners to expedite the identification and acquisition of parts and pieces of difficult access.',
    'content4.section2' => 'All of our pieces, modules or cards have a full 12 month warranty.',

    'content1.section3' => 'Our company understands and is aligned with the objectives of the industries in sectors such as energy, textile, chemical and others around the world and offers a supply of spare parts for control systems which allow professionals of modern manufacturing, work faster and more efficiently and smarter. ',
    'content2.section3' => 'Our services are specifically designed to provide the supply of parts and pieces for automation systems, both new, restored or discontinued agree with the fundamental characteristics of speed, scope or cost of the investment.',


    'content1.section4' => 'Our success in large part has been based on the attention and support that we offer to our customers around the world, with a direct and personal treatment, with the main objective to ensure your satisfaction.',
    'content2.section4' => 'Our team is ready to advise, locate you and send you your order in the shortest possible time, according to the needs that today requires modern industry.',
];