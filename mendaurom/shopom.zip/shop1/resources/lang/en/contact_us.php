<?php
/**
 * Created by PhpStorm.
 * User: JM
 * Date: 4/4/2016
 * Time: 10:37 p.m.
 */

return [
    'title.page' => 'Contact Us',
    'column1.title' => 'Contact us',
    'slogan' => 'We are here to answer any questions you may have.',
    'form.title' => 'Your details',
    'label.name' => 'Name',
    'label.email' => 'E-Mail',
    'label.subject' => 'Subject',
    'label.message' => 'Your message',
    'button.send' => 'Send',

    'colum2.title' => 'Where we are',

    'error' => 'There are problems to send your message',
];